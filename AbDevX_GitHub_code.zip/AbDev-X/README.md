# AbDev-X manuscript reproducibility

Code, workflows, provenance records, and the complete final manuscript for
**AbDev-X: Assay-Aware Expert Ensembles for Antibody Developability Prediction under Distribution Shift**.

The primary model is an equal-weight average of four assay-specific experts:
E1 source selection, A-MGFS descriptor masking, D-Stack prediction stacking,
and F-MoE mechanistic feature-group prediction. It uses five operational blocks.
It is not a jointly trained neural ten-task model. The structural-source20
comparison is a separate controlled variant, not a replacement of primary bio57.

## Layout

| Folder | Contents |
|---|---|
| `src/abdev/` | Dataset loading, descriptors, embeddings, models, evaluation utilities |
| `workflows/` | Organized entry points for the manuscript experiments and figures |
| `scripts/` | Original research modules retained at their audited import paths |
| `paper/paper10assay/` | Exact experiment/figure scripts and historical dependencies |
| `configs/` | Dataset schema, fold definitions, and original experiment configurations |
| `reference/` | Expected aggregate metrics, source hashes, and input inventory |
| `third_party/delphi/` | Exact MIT-licensed comparator implementation, with its license |
| `manuscript/` | Latest combined main/SI `.tex`, `.bib`, bibliography style, figures, PDFs |
| `tools/` | Numeric verification, input validation, structure preparation utilities |
| `assets/architecture/` | Author-edited PowerPoint architecture source |
| `docs/` | Environment setup, provenance, complete workflow and limitations |
| `data/`, `external/`, `results/` | Local inputs and outputs; excluded from Git |
| `outputs/` | New logs and verification reports; excluded from Git |

Older module paths are deliberately retained because imports, cached model
classes, source hashes, and historical plotting scripts use them. Use
`reproduce.py` and the workflow map rather than the old `scripts/run_all.py`,
which predates the primary four-expert manuscript model.

## Setup

Use Python 3.11. The working package versions are recorded in
`environment_record.json`; AF3 and ChimeraX require separate runtimes.

```bash
python -m venv .venv
# Activate .venv using your shell's activation command.
python -m pip install -r requirements-models.txt
python -m pip install -e .
python reproduce.py list
```

For CUDA, install the appropriate PyTorch 2.6 build for your platform. The
recorded training environment used CUDA 12.4. CPU runs are supported by the
primary model; transformer training and structure inference are faster on GPU.
See [environment instructions](docs/ENVIRONMENTS.md).

## Verify and reproduce

This supplied local folder contains the original working inputs and retained
artifacts in Git-ignored paths. A fresh GitHub clone does not contain them.
Acquire provider-controlled datasets and representations as described in
[data access](docs/DATA_ACCESS.md) before attempting a fresh clone reproduction.
Do not upload tokens, pretrained weights, or gated data with the code.

```bash
# Recalculate correlations/AUCs and cross-validation summaries from retained
# predictions, comparing them with the frozen manuscript reference metrics.
python reproduce.py run verify

# Refit the primary model from the cached representations and original labels.
python reproduce.py run primary
python reproduce.py run cross_validation
python reproduce.py run ablations
python reproduce.py run verify

# Matched-data DELPHI training and paired statistics.
python reproduce.py run delphi_regression
python reproduce.py run delphi_classification
python reproduce.py run delphi_statistics

# Controlled structural-source comparison from identical extracted features.
python reproduce.py run structure_comparison

# Reproduce the numerical plots and compile the final manuscript.
python reproduce.py run figures
python reproduce.py run manuscript
```

`python reproduce.py run all --dry-run` lists the full supported sequence.
`run all` includes expensive encoder, attribution, and training stages. It uses
the original input representations and structural-feature tables; it does not
silently install predictors or regenerate every external structural feature.
Inference and ChimeraX commands are documented separately.

Execution stops on failure and writes stage logs under `outputs/run_logs/`.
Reference metrics are kept in `reference/` and are not overwritten by training.
The verification tool fails if recalculated values disagree with them.

## Scope of reproducibility

The primary ensemble, matched DELPHI comparisons, conditional residue
attributions, matched GP experiments, and common-structure comparisons have
executable code and retained prediction records. Some historical supplementary
points have only summary tables. Their plots can be regenerated, but their
original training experiments and missing uncertainty cannot be reconstructed.
See the [result-by-result map](docs/RESULT_PROVENANCE.md).

The original 57-feature bio cache includes TAP, MOE, Aggrescan3D, and AntiFold.
Its complete upstream generation pipeline is not available here. MOE is
proprietary. Reusing that cache and regenerating the open structural-source20
panel are different workflows. The manuscript's structural comparison does not
establish an optimal predictor for the original bio57 pipeline.

## Publishing this folder

The repository URL supplied by the authors is
https://github.com/harshitsinghsnu/AbDev-X . This folder is prepared locally;
no push or repository visibility change is performed.

Review `git status` before committing. The `.gitignore` excludes local datasets,
cached representations, models, copied third-party packages, historical figure
caches, and run logs. Publish an authorized input/derived-artifact archive with
a persistent identifier if readers are to reproduce the cached-input route.
The input manifest records the exact files and SHA-256 hashes to identify.

No license is invented for the authors' code. Select an appropriate source-code
license before public release. Third-party tools and data retain their own terms.

`python tools/audit_release.py` checks the Git-visible files for large binary
inputs and common credential patterns, then creates a code-only ZIP alongside
this folder. It does not stage, commit, or push any changes. The larger local
folder includes working data and caches for validation; the code-only ZIP omits
all paths excluded by Git.
