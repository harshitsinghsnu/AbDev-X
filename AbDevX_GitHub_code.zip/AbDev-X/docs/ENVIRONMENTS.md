# Environments

## CPU analysis

`requirements.txt` pins the recorded NumPy, pandas, SciPy, scikit-learn,
BioPython, Matplotlib, PyMuPDF, and supporting packages. Install the package
with `pip install -e .` so `abdev` is importable.

`requirements-models.txt` adds PyTorch, Transformers, LightGBM, SHAP, and AbLang2.
The exact AbLang2 representation cache is authoritative for the manuscript:
regeneration must preserve its paired-chain pooling and 480-column layout.
Do not substitute a different embedding dimensionality because a newer package
has changed its defaults. The recorded ESM-2 primary block has 2,560 columns.

ANARCI numbering is optional in some historical paths and may require a
separate bioconda environment. Preserve the existing annotation convention when
regenerating descriptors; compare outputs against the primary reproduction.

## Structure generation

IgFold 1.0.1, AntiBERTy 1.0.0, OpenMM 8.6.1, and PDBFixer 1.12 were installed
separately. Install PDBFixer from https://github.com/openmm/pdbfixer following
its official build instructions. FreeSASA is required for the common panel.

Run these from the repository root in the structure environment:

```bash
python tools/prepare_structure_inputs.py
python paper/paper10assay/structure_predictor_benchmark/download_weights.py esmfold
python paper/paper10assay/structure_predictor_benchmark/run_igfold.py
python paper/paper10assay/structure_predictor_benchmark/run_esmfold.py
python paper/paper10assay/structure_predictor_benchmark/extract_parallel.py IgFold --workers 4
python paper/paper10assay/structure_predictor_benchmark/extract_parallel.py ESMFold --workers 4
```

AF3 requires Linux and an independent CUDA/JAX environment. The working run
used official AF3 v3.0.1 with JAX 0.4.34, CUDA 12 libraries, xla attention,
seed 42, 10 recycles, five diffusion samples, and no MSAs/templates. Follow
https://github.com/google-deepmind/alphafold3 for installation and parameter
terms. Do not use the copied historical `run_remaining.py` WSL orchestration
script on a different computer; it is retired in this portable release.

```bash
# In the AF3 Linux environment, with the official source and weights installed:
python tools/run_af3.py --source /path/to/alphafold3 --weights /path/to/weights
python paper/paper10assay/structure_predictor_benchmark/collect_af3.py
python paper/paper10assay/structure_predictor_benchmark/extract_parallel.py AlphaFold3 --workers 4
```

The ESMFold source and weight revision is pinned in `download_weights.py`.
Paired-chain encoding uses a 25-glycine linker and a light-chain index offset
of 512; linker atoms are excluded. The language model is half precision and
folding components single precision. IgFold optional refinement is disabled;
the common missing-heavy-atom policy is applied before extracting features.

The controlled comparison uses the complete-case intersection of structures.
Missing source structures are not replaced with zero features.

## Molecular visualization and manuscript

Install UCSF ChimeraX 1.11.1 separately under its terms. From the repository:

```bash
ChimeraX --script paper/paper10assay/render_chimerax_clean.py
```

The script reads the primary residue attribution table, applies the same signed
colors, and saves ten cartoons and session files. A graphical rendering context
is required on Windows; the original Windows offscreen attempt did not work.
The compiled manuscript uses the ChimeraX renders, not licensed PyMOL output.

For TeX, use TeX Live/MiKTeX with `pdflatex` and `bibtex` on PATH, or upload
`manuscript/` to Overleaf. The final sources include their local bibliography
style and all referenced figures.
