AbDev-X: complete manuscript and supplementary information source package

Contents
  main.tex                         Main + SI, using references.bib
  references.bib                   All 42 references, with standard metadata
  bmc_vancouver.bst                 Style preserving the manuscript references
  main_inline.tex                  Identical text with an inline bibliography
  AbDevX_BMC_polished_main_SI.pdf    Latest reviewed compiled PDF
  main.pdf                         PDF compiled from the BibTeX-enabled source
  figures/                         Every referenced figure PDF; SVG/PNG variants
                                    are included wherever available
  package_manifest.json            Figure list and SHA-256 checksums

Build from this folder using an installed TeX distribution:
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  bibtex main
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  pdflatex -interaction=nonstopmode -halt-on-error main.tex

For Overleaf, upload the ZIP and select main.tex as the main document.
No absolute paths or project files outside this folder are required.
The local bibliography style preserves the existing Vancouver reference wording
and citation order using each entry's formatted field. Standard author, title,
year, journal, volume, pages, DOI and URL fields are provided where applicable
for reuse with other styles. If editing reference wording with this style, edit
the formatted field too.

Fallback without BibTeX:
  pdflatex -interaction=nonstopmode -halt-on-error main_inline.tex
  pdflatex -interaction=nonstopmode -halt-on-error main_inline.tex

Both sources contain the complete main paper and supplementary information.
Figure PDFs are the exact assets used in the latest reviewed manuscript.
