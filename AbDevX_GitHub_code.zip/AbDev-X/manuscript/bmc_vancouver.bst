% Preserve the reference wording and numeric citation order of this manuscript.
ENTRY { author title journal year volume pages doi url note formatted } {} {}
FUNCTION {output.entry}
{ newline$ "\bibitem{" write$ cite$ write$ "}" write$ newline$
  formatted empty$ { title write$ } { formatted write$ } if$
  newline$
}
FUNCTION {article} { output.entry }
FUNCTION {misc} { output.entry }
FUNCTION {default.type} { output.entry }
READ
FUNCTION {begin.bib}
{ "\begin{thebibliography}{99}" write$ newline$ }
FUNCTION {end.bib}
{ newline$ "\end{thebibliography}" write$ newline$ }
EXECUTE {begin.bib}
ITERATE {call.type$}
EXECUTE {end.bib}
