"""Regenerate numerical plot panels while retaining supplied archival artwork."""
from pathlib import Path
import runpy,sys,shutil,os
R=Path(__file__).resolve().parents[2];P=R/'paper/paper10assay';os.chdir(R)
sys.path[:0]=[str(P/'assay_revision'),str(P/'publication_revision'),str(P/'verified_revision'),str(R/'scripts'),str(R/'src')]
import make_revision_figures as m
base=P/'bmc_formatted_revision/figures';base.mkdir(exist_ok=True)
# Git excludes historical rendered caches. Seed the retained artwork from the
# final, Git-visible manuscript package before rebuilding numerical panels.
for directory in [P/'assay_revision/figures',P/'publication_revision/figures',P/'verified_revision/figures',P/'primary_attribution_revision/figures',P/'benchmark_pymol_revision/figures',P/'si_narrative_revision/figures',base]:
 directory.mkdir(parents=True,exist_ok=True)
 for asset in (R/'manuscript/figures').iterdir():
  if asset.is_file() and not (directory/asset.name).exists():shutil.copy2(asset,directory/asset.name)
for fn in [m.encoders,m.soft_extensions,m.detailed_shap,m.headline,m.main_context_and_learning]:
 print('Figure function',fn.__name__,flush=True);fn()
m.b.generalization()
for directory in [P/'assay_revision/figures',P/'publication_revision/figures']:
 for f in directory.glob('*'):
  if f.is_file() and f.suffix in ['.pdf','.png','.svg']:shutil.copy2(f,base/f.name)
runpy.run_path(str(P/'si_narrative_revision/revise_si.py'),run_name='__main__')
for f in (P/'si_narrative_revision/figures').glob('*'):
 if f.is_file() and f.suffix in ['.pdf','.png','.svg']:shutil.copy2(f,base/f.name)
# Reuse only the numerical baseline/GP panel from the older combined script.
# Its following attribution block expects obsolete licensed PyMOL renders;
# the current attribution panel is rebuilt with ChimeraX below.
baseline_script=P/'finish_benchmark_pymol.py'
baseline_source=baseline_script.read_text(encoding='utf8').split('# Reuse the established three-row attribution layout')[0]
exec(compile(baseline_source,str(baseline_script),'exec'),{'__file__':str(baseline_script),'__name__':'__main__'})
for f in (P/'benchmark_pymol_revision/figures').glob('main07_baseline_context.*'):shutil.copy2(f,base/f.name)
runpy.run_path(str(P/'build_clean_layout.py'),run_name='__main__')
runpy.run_path(str(P/'revise_requested_bars.py'),run_name='__main__')
runpy.run_path(str(P/'polish_abstract_format.py'),run_name='__main__')
print('Figures rebuilt under paper/paper10assay/abstract_format_revision/figures')
