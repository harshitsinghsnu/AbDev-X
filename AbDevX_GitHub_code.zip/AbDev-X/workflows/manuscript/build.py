from pathlib import Path
import subprocess,shutil
R=Path(__file__).resolve().parents[2];P=R/'manuscript'
generated=R/'paper/paper10assay/abstract_format_revision/figures'
if generated.exists():
 for asset in (P/'figures').iterdir():
  source=generated/asset.name
  if source.is_file():shutil.copy2(source,asset)
for program,args in [('pdflatex',['-interaction=nonstopmode','-halt-on-error','main.tex']),('bibtex',['main']),('pdflatex',['-interaction=nonstopmode','-halt-on-error','main.tex']),('pdflatex',['-interaction=nonstopmode','-halt-on-error','main.tex'])]:
 executable=shutil.which(program)
 if not executable:raise SystemExit(program+' is not on PATH. Install TeX Live/MiKTeX or build manuscript/main.tex in Overleaf.')
 subprocess.run([executable]+args,cwd=P,check=True)
